@extends('layouts.app')

@section('content')
    <h1>Editar Produto</h1>

    <form action="{{ route('produtos.update', $produto->id) }}" method="POST">
        @csrf
        @method('PUT')
        <label for="nome">Nome:</label>
        <input type="text" name="nome" value="{{ $produto->nome }}" required>

        <label for="descricao">Descrição:</label>
        <textarea name="descricao" required>{{ $produto->descricao }}</textarea>

        <label for="quantidade">Quantidade:</label>
        <input type="number" name="quantidade" value="{{ $produto->quantidade }}" required>

        <label for="valor">Valor:</label>
        <input type="text" name="valor" value="{{ $produto->valor }}" required>

        <label for="categoria">Categoria:</label>
        <input type="text" name="categoria" value="{{ $produto->categoria }}" required>

        <label for="estado_origem">Estado de Origem:</label>
        <select name="estado_origem" required>
            <option value="estado1" {{ $produto->estado_origem === 'estado1' ? 'selected' : '' }}>SC</option>
            <option value="estado2" {{ $produto->estado_origem === 'estado2' ? 'selected' : '' }}>RS</option>
            <option value="estado2" {{ $produto->estado_origem === 'estado2' ? 'selected' : '' }}>PR</option>
        </select>

        <button type="submit">Salvar</button>
    </form>

    <a href="{{ route('produtos.index') }}">Voltar para Lista de Produtos</a>
@endsection

